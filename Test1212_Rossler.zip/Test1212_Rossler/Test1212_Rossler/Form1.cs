﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test1212_Rossler
{
    public partial class Form1 : Form
    {
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Employees;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        SqlRepository sqlRepository;
        public Form1()
        {
            InitializeComponent();
            sqlRepository = new SqlRepository(connectionString);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        public void LoadData()
        {
            lVMain.Items.Clear();
            var lidi = sqlRepository.GetLidis();
            foreach (var l in lidi)
            {
                lVMain.Items.Add(new ListViewItem(new string[] { l.Id.ToString(), l.Jmeno, l.Prijmeni, l.Email, l.Telefon, l.Narozeni.ToString() }));
            }
        }

        private void buttonPridat_Click(object sender, EventArgs e)
        {
            if (textBoxTelefon.Text != "")
            {
                sqlRepository.AddLidi(textBoxJmeno.Text, textBoxPrijmeni.Text, textBoxEmail.Text, textBoxTelefon.Text, Convert.ToDateTime(textBoxNarozeni.Text));
                LoadData();
            }
            else
            {
                MessageBox.Show("Nefunguje, zadej všechno pls");
            }
        }

        private void buttonOdstranit_Click(object sender, EventArgs e)
        {
            if (lVMain.SelectedItems.Count > 0)
            {
                sqlRepository.DeleteLidi(lVMain.SelectedItems[0].SubItems[0].Text);
                LoadData();
            }
            else
            {
                MessageBox.Show("Nepodařilo se vymazat");
            }
        }

        private void lVMain_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (lVMain.SelectedItems.Count > 0)
            {
                IdSchranka = lVMain.SelectedItems[0].SubItems[0].Text;
                tbEdit1.Text = lVMain.SelectedItems[0].SubItems[1].Text;
                tbEdit2.Text = lVMain.SelectedItems[0].SubItems[2].Text;
                tbEdit3.Text = lVMain.SelectedItems[0].SubItems[3].Text;
                tbEdit4.Text = lVMain.SelectedItems[0].SubItems[4].Text;
                tbEdit5.Text = lVMain.SelectedItems[0].SubItems[5].Text;
            }
            else
            {
                MessageBox.Show("Nepodařilo se editovat, lol");
            }
        }

        private void buttonEditovat_Click(object sender, EventArgs e)
        {
            if (tbEdit1.Text != "")
            {
                sqlRepository.EditLidi(tbEdit1.Text, tbEdit2.Text, tbEdit3.Text, tbEdit4.Text, Convert.ToDateTime(tbEdit5.Text), IdSchranka);
                LoadData();
            }
            else
            {
                MessageBox.Show("Je potřeba vyplnit boxy");
            }
        }
        string IdSchranka = "";
    }
    }

