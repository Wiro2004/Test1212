﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1212_Rossler
{
    public class Lidi
    {
        public Lidi(int id, string jmeno, string prijmeni, string email, string telefon, string narozeni)
        {
            Id = id;
            Jmeno = jmeno;
            Prijmeni = prijmeni;
            Email = email;
            Telefon = telefon;
            Narozeni = narozeni;
        }

        public int Id { get; set; }
        public string Jmeno { get; set; }
        public string Prijmeni { get; set; }
        public string Email { get; set; }
        public string Telefon { get; set; }
        public string Narozeni { get; set; }
    }
}

