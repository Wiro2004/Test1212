﻿namespace Test1212_Rossler
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewGroup listViewGroup13 = new System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup14 = new System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup15 = new System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup16 = new System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup17 = new System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup18 = new System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left);
            this.lVMain = new System.Windows.Forms.ListView();
            this.ColumnId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnFirstname = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnLastname = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnPhone = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnEmail = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnBirthdate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.buttonPridat = new System.Windows.Forms.Button();
            this.textBoxJmeno = new System.Windows.Forms.TextBox();
            this.textBoxPrijmeni = new System.Windows.Forms.TextBox();
            this.textBoxTelefon = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxNarozeni = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonOdstranit = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonEditovat = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tbEdit1 = new System.Windows.Forms.TextBox();
            this.tbEdit2 = new System.Windows.Forms.TextBox();
            this.tbEdit3 = new System.Windows.Forms.TextBox();
            this.tbEdit4 = new System.Windows.Forms.TextBox();
            this.tbEdit5 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lVMain
            // 
            this.lVMain.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ColumnId,
            this.ColumnFirstname,
            this.ColumnLastname,
            this.ColumnPhone,
            this.ColumnEmail,
            this.ColumnBirthdate});
            this.lVMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lVMain.FullRowSelect = true;
            this.lVMain.GridLines = true;
            listViewGroup13.Header = "ListViewGroup";
            listViewGroup13.Name = "listViewId";
            listViewGroup14.Header = "ListViewGroup";
            listViewGroup14.Name = "listViewFirstname";
            listViewGroup15.Header = "ListViewGroup";
            listViewGroup15.Name = "listViewLastname";
            listViewGroup16.Header = "ListViewGroup";
            listViewGroup16.Name = "listViewPhone";
            listViewGroup17.Header = "ListViewGroup";
            listViewGroup17.Name = "listViewEmail";
            listViewGroup18.Header = "ListViewGroup";
            listViewGroup18.Name = "listViewBirthdate";
            this.lVMain.Groups.AddRange(new System.Windows.Forms.ListViewGroup[] {
            listViewGroup13,
            listViewGroup14,
            listViewGroup15,
            listViewGroup16,
            listViewGroup17,
            listViewGroup18});
            this.lVMain.HideSelection = false;
            this.lVMain.Location = new System.Drawing.Point(0, 0);
            this.lVMain.Name = "lVMain";
            this.lVMain.Size = new System.Drawing.Size(800, 450);
            this.lVMain.TabIndex = 0;
            this.lVMain.UseCompatibleStateImageBehavior = false;
            this.lVMain.View = System.Windows.Forms.View.Details;
            this.lVMain.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lVMain_MouseDoubleClick);
            // 
            // ColumnId
            // 
            this.ColumnId.Text = "Id";
            this.ColumnId.Width = 40;
            // 
            // ColumnFirstname
            // 
            this.ColumnFirstname.Text = "Firstname";
            this.ColumnFirstname.Width = 79;
            // 
            // ColumnLastname
            // 
            this.ColumnLastname.Text = "Lastname";
            this.ColumnLastname.Width = 77;
            // 
            // ColumnPhone
            // 
            this.ColumnPhone.Text = "Phone";
            this.ColumnPhone.Width = 57;
            // 
            // ColumnEmail
            // 
            this.ColumnEmail.Text = "Email";
            this.ColumnEmail.Width = 54;
            // 
            // ColumnBirthdate
            // 
            this.ColumnBirthdate.Text = "Birthdate";
            this.ColumnBirthdate.Width = 72;
            // 
            // buttonPridat
            // 
            this.buttonPridat.Location = new System.Drawing.Point(683, 12);
            this.buttonPridat.Name = "buttonPridat";
            this.buttonPridat.Size = new System.Drawing.Size(96, 30);
            this.buttonPridat.TabIndex = 1;
            this.buttonPridat.Text = "Přidat ";
            this.buttonPridat.UseVisualStyleBackColor = true;
            this.buttonPridat.Click += new System.EventHandler(this.buttonPridat_Click);
            // 
            // textBoxJmeno
            // 
            this.textBoxJmeno.Location = new System.Drawing.Point(683, 71);
            this.textBoxJmeno.Name = "textBoxJmeno";
            this.textBoxJmeno.Size = new System.Drawing.Size(100, 22);
            this.textBoxJmeno.TabIndex = 2;
            // 
            // textBoxPrijmeni
            // 
            this.textBoxPrijmeni.Location = new System.Drawing.Point(683, 111);
            this.textBoxPrijmeni.Name = "textBoxPrijmeni";
            this.textBoxPrijmeni.Size = new System.Drawing.Size(100, 22);
            this.textBoxPrijmeni.TabIndex = 3;
            // 
            // textBoxTelefon
            // 
            this.textBoxTelefon.Location = new System.Drawing.Point(683, 148);
            this.textBoxTelefon.Name = "textBoxTelefon";
            this.textBoxTelefon.Size = new System.Drawing.Size(100, 22);
            this.textBoxTelefon.TabIndex = 4;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(683, 185);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(100, 22);
            this.textBoxEmail.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(588, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 16);
            this.label1.TabIndex = 7;
            this.label1.Text = "Jméno";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(588, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 16);
            this.label2.TabIndex = 8;
            this.label2.Text = "Příjmení";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(590, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "Telefon";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(588, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 16);
            this.label4.TabIndex = 10;
            this.label4.Text = "Email";
            // 
            // textBoxNarozeni
            // 
            this.textBoxNarozeni.Location = new System.Drawing.Point(683, 228);
            this.textBoxNarozeni.Name = "textBoxNarozeni";
            this.textBoxNarozeni.Size = new System.Drawing.Size(100, 22);
            this.textBoxNarozeni.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(588, 228);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 16);
            this.label5.TabIndex = 12;
            this.label5.Text = "Narozeni";
            // 
            // buttonOdstranit
            // 
            this.buttonOdstranit.Location = new System.Drawing.Point(683, 301);
            this.buttonOdstranit.Name = "buttonOdstranit";
            this.buttonOdstranit.Size = new System.Drawing.Size(96, 34);
            this.buttonOdstranit.TabIndex = 13;
            this.buttonOdstranit.Text = "Odstranit";
            this.buttonOdstranit.UseVisualStyleBackColor = true;
            this.buttonOdstranit.Click += new System.EventHandler(this.buttonOdstranit_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 284);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 16);
            this.label6.TabIndex = 14;
            this.label6.Text = "Edit";
            // 
            // buttonEditovat
            // 
            this.buttonEditovat.Location = new System.Drawing.Point(275, 404);
            this.buttonEditovat.Name = "buttonEditovat";
            this.buttonEditovat.Size = new System.Drawing.Size(96, 34);
            this.buttonEditovat.TabIndex = 15;
            this.buttonEditovat.Text = "Editovat";
            this.buttonEditovat.UseVisualStyleBackColor = true;
            this.buttonEditovat.Click += new System.EventHandler(this.buttonEditovat_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(30, 310);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 16);
            this.label7.TabIndex = 16;
            this.label7.Text = "Jméno";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 335);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 16);
            this.label8.TabIndex = 17;
            this.label8.Text = "Příjmení";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(30, 361);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 16);
            this.label9.TabIndex = 18;
            this.label9.Text = "Telefon";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(30, 391);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 16);
            this.label10.TabIndex = 19;
            this.label10.Text = "Email";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(30, 416);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 16);
            this.label11.TabIndex = 20;
            this.label11.Text = "Narozeni";
            // 
            // tbEdit1
            // 
            this.tbEdit1.Location = new System.Drawing.Point(89, 310);
            this.tbEdit1.Name = "tbEdit1";
            this.tbEdit1.Size = new System.Drawing.Size(100, 22);
            this.tbEdit1.TabIndex = 21;
            // 
            // tbEdit2
            // 
            this.tbEdit2.Location = new System.Drawing.Point(89, 335);
            this.tbEdit2.Name = "tbEdit2";
            this.tbEdit2.Size = new System.Drawing.Size(100, 22);
            this.tbEdit2.TabIndex = 22;
            // 
            // tbEdit3
            // 
            this.tbEdit3.Location = new System.Drawing.Point(89, 363);
            this.tbEdit3.Name = "tbEdit3";
            this.tbEdit3.Size = new System.Drawing.Size(100, 22);
            this.tbEdit3.TabIndex = 23;
            // 
            // tbEdit4
            // 
            this.tbEdit4.Location = new System.Drawing.Point(89, 391);
            this.tbEdit4.Name = "tbEdit4";
            this.tbEdit4.Size = new System.Drawing.Size(100, 22);
            this.tbEdit4.TabIndex = 24;
            // 
            // tbEdit5
            // 
            this.tbEdit5.Location = new System.Drawing.Point(89, 416);
            this.tbEdit5.Name = "tbEdit5";
            this.tbEdit5.Size = new System.Drawing.Size(100, 22);
            this.tbEdit5.TabIndex = 25;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tbEdit5);
            this.Controls.Add(this.tbEdit4);
            this.Controls.Add(this.tbEdit3);
            this.Controls.Add(this.tbEdit2);
            this.Controls.Add(this.tbEdit1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.buttonEditovat);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.buttonOdstranit);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxNarozeni);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.textBoxTelefon);
            this.Controls.Add(this.textBoxPrijmeni);
            this.Controls.Add(this.textBoxJmeno);
            this.Controls.Add(this.buttonPridat);
            this.Controls.Add(this.lVMain);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lVMain;
        private System.Windows.Forms.ColumnHeader ColumnId;
        private System.Windows.Forms.ColumnHeader ColumnFirstname;
        private System.Windows.Forms.ColumnHeader ColumnLastname;
        private System.Windows.Forms.ColumnHeader ColumnPhone;
        private System.Windows.Forms.ColumnHeader ColumnEmail;
        private System.Windows.Forms.ColumnHeader ColumnBirthdate;
        private System.Windows.Forms.Button buttonPridat;
        private System.Windows.Forms.TextBox textBoxJmeno;
        private System.Windows.Forms.TextBox textBoxPrijmeni;
        private System.Windows.Forms.TextBox textBoxTelefon;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxNarozeni;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonOdstranit;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonEditovat;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbEdit1;
        private System.Windows.Forms.TextBox tbEdit2;
        private System.Windows.Forms.TextBox tbEdit3;
        private System.Windows.Forms.TextBox tbEdit4;
        private System.Windows.Forms.TextBox tbEdit5;
    }
}

