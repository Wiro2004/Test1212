﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;


namespace Test1212_Rossler
{
    public class SqlRepository
    {
        public SqlRepository(string connectionString)
        {
            ConnectionString = connectionString;

        }
        public List<Lidi> GetLidis()
        {
            List<Lidi> result = new List<Lidi>();

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandText = "Select * from employes";
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(new Lidi((int)reader["Id"], reader["FirstName"].ToString(), reader["LastName"].ToString(), reader["Phone"].ToString(), reader["Email"].ToString(), reader["Birthdate"].ToString()));
                        }
                    }
                }
                connection.Close();
            }
            return result;
        }
        public void AddLidi(string jmeno, string prijmeni, string email, string telefon, DateTime narozeni)
        {
            
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandText = $"Insert into employes values(@jmeno,@prijmeni,@telefon,@email,@narozeni)";
                    command.Parameters.AddWithValue("@jmeno", jmeno);
                    command.Parameters.AddWithValue("@prijmeni", prijmeni);
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@telefon", telefon);
                    command.Parameters.AddWithValue("@narozeni", narozeni);
                    command.ExecuteNonQuery();
                }
                connection.Close();
            }
        }
        public string ConnectionString { get; set; }
        public void DeleteLidi(string meno)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandText = $"delete from employes where Id=@vymazani ";
                    command.Parameters.AddWithValue("@vymazani", meno);
                    command.ExecuteNonQuery();
                }
                connection.Close();
            }
        }

        public void EditLidi(string noveJmeno, string novePrijmeni, string novyTelefon, string novyEmail, DateTime noveNarozeni, string IdSchran)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = connection.CreateCommand())
                {
                
                    command.CommandText = $"update employes set  FirstName=@noveJmeno, LastName=@novePrijmeni,Email=@novyEmail, Phone=@novyTelefon, BirthDate=@noveNarozeni where Id=@noveId ";
                    command.Parameters.AddWithValue("@noveJmeno", noveJmeno);
                    command.Parameters.AddWithValue("@novePrijmeni", novePrijmeni);
                    command.Parameters.AddWithValue("@novyTelefon", novyTelefon);
                    command.Parameters.AddWithValue("@novyEmail", novyEmail);
                    command.Parameters.AddWithValue("@noveNarozeni", noveNarozeni);
                    command.Parameters.AddWithValue("@noveId", IdSchran);
                    command.ExecuteNonQuery();
                }
                connection.Close();
            }
        }

    }



   
}
