﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace Test1212_Rossler
{
    internal class SqlRepository
    {
        public SqlRepository(string connectionString)
        {
            ConnectionString = connectionString;
        }
        public string ConnectionString { get; set; }
    }

    public List<Lidi> GetLidis()
    {
        List<Lidi> result = new List<Lidi>();
        string ConnectionString = null;
        using (SqlConnection connection = new SqlConnection(ConnectionString)) 
        {
            connection.Open();
            using (SqlCommand command = connection.CreateCommand())
            {
                command.CommandText = "Select * from employes";
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new Lidi((int)reader["Id"], reader["FirstName"].ToString(), reader["LastName"].ToString(), reader["Phone"].ToString(), reader["Email"].ToString(), reader["Birthdate"].ToString()));
                    }
                }
            }
            connection.Close();
        }
        return result;
    }
    public void AddLidi(string jmeno, string prijmeni, string email, string telefon, string narozeni)
    {
        string ConnectionString = null;
        using (SqlConnection connection = new SqlConnection(ConnectionString))
        {
            connection.Open();
            using (SqlCommand command = connection.CreateCommand())
            {
                command.CommandText = $"Insert into employes values(@jmeno,@prijmeni,@email,@telefon,@narozeni)";
                command.Parameters.AddWithValue("jmeno", jmeno);
                command.Parameters.AddWithValue("prijmeni", prijmeni);
                command.Parameters.AddWithValue("email", email);
                command.Parameters.AddWithValue("telefon", telefon);
                command.Parameters.AddWithValue("narozeni", narozeni);
                command.ExecuteNonQuery();
            }
            connection.Close();
        }
    }
}
